<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="../frontend/js/app.js" defer></script>
    <style>
        body {
            /* background-color: #f5f5f5; */
            background-image: url(mana.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 100%;
            max-width: 400px;
        }
        h1 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="text"],
        input[type="password"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 16px;
        }
        #error {
            color: red;
            margin-bottom: 10px;
            display: none;
        }
        button {
            background-color: #38a169;
            color: #fff;
            border: none;
            padding: 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #2c7a52;
        }
        a {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: #3490dc;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <form id="loginForm" action="../api/login.php" method="POST">
            <input type="text" name="usernameOrEmail" placeholder="Username or Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <div id="error">Invalid username or password</div>
            <button type="submit">Login</button>
        </form>
        <a href="register">Don't have an account? Register</a>
    </div>
</body>
</html>
